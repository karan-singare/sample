function start() {
    updateCurrentDates();
    // updateCalenderDates();
    fillInCalender();
}
start();
