function updateCurrentDates() {
    let today = new Date();
    let date = today.getDate();
    let day = today.getDay();
    let month = today.getMonth();//returns values from 0-11
    let year = today.getFullYear();

    data.current_date.day = day;
    data.current_date.date = date;
    data.current_date.year = year;
    data.current_date.month = month;

    data.calender.month = month;
    data.calender.year = year;

    document.getElementById('current-year').innerHTML = year;
    document.getElementById('current-month').innerHTML = translateToMonth(month);
    document.getElementById('current-day').innerHTML = translateToWeekDay(day);
    document.getElementById('current-date').innerHTML = addOrdinalIndicator(date);
}
function updateCalenderDates() {
    document.getElementById('cal-year').innerHTML = data.calender.year;
    document.getElementById('cal-month').innerHTML = translateToMonth(data.calender.month);
}

function addOrdinalIndicator(date) {
    switch(date) {
        case 1:
        case 21:
        case 31:
            return date + "<sup>st</sup>";
        case 2:
        case 22:
            return date + "<sup>nd</sup>";
        case 3:
        case 23:
            return date + "<sup>rd</sup>";
        default:
            return date + "<sup>th</sup>";
    }
}
function translateToWeekDay(day) {
    switch(day) {
        case 0:
            day = "Sunday";
            break;
        case 1:
            day = "Monday";
            break;
        case 2:
            day = "Tuesday";
            break;
        case 3:
            day = "Wednesday";
            break;
        case 4:
            day = "Thursday";
            break;
        case 5:
            day = "Friday";
            break;
        case 6:
            day = "Saturday";
            break;

    }
    return day;
}
function translateToMonth(month) {
    switch(month) {
        case 0:
            month = "January";
            break;
        case 1:
            month = "February";
            break;
        case 2:
            month = "March";
            break;
        case 3:
            month = "April";
            break;
        case 4:
            month = "May";
            break;
        case 5:
            month = "June";
            break;
        case 6:
            month = "July";
            break;
        case 7:
            month = "August";
            break;
        case 8:
            month = "September";
            break;
        case 9:
            month = "October";
            break;
        case 10:
            month = "November";
            break;
        case 11:
            month = "December";
    }
    return month;
}
