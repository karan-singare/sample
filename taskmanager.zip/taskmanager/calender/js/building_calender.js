function fillInCalender() {
    updateCalenderDates();
    var td_array = document.getElementsByTagName('td');
    addEventToArray(td_array);

    var monthOfFillIn = {};
    var previousMonthIndex;
    month_data.forEach(function(month, i) {
        if (month.year == data.calender.year && month.month_index == data.calender.month) {
            monthOfFillIn = month;
            previousMonthIndex = i - 1;
            return;
        }
    });

    let days = document.getElementsByTagName('td');
    let currentMonthCount = 1;
    let previousMonthCount = month_data[previousMonthIndex].amount_of_days - monthOfFillIn.starting_day + 1;
    let nextMonthCount = 1;
    let uid;
    cleanCells(days);

    for (let i = 0; i < days.length; i++) {
        //Filling Current Month
        if (monthOfFillIn.starting_day <= i && currentMonthCount <= monthOfFillIn.amount_of_days) {
            days[i].innerHTML = currentMonthCount;
            uid = getUID(currentMonthCount, monthOfFillIn.month_index, monthOfFillIn.year);
            days[i].setAttribute('data-uid', uid);
            if(currentMonthCount == data.current_date.date && calenderIsCurrentMonth()){
                days[i].setAttribute('id','current-day');
            }
            appendSpriteToCellAndTolltip(uid,days[i]);
            currentMonthCount++;
        //Filling previous month
        } else if (currentMonthCount <= monthOfFillIn.amount_of_days) {
            days[i].classList.add('color');
            days[i].innerHTML = previousMonthCount;
            uid = getUID(previousMonthCount, month_data[previousMonthIndex].month_index, month_data[previousMonthIndex].year);
            days[i].setAttribute('data-uid', uid);
            // if(previousMonthCount == month_data[previousMonthIndex].amount_of_days) {
            //     days[i].classList.add('prev-month-last-day');
            // }
            appendSpriteToCellAndTolltip(uid,days[i]);
            previousMonthCount++;
            //Filling next month
        } else {
            days[i].classList.add('color');
            days[i].innerHTML = nextMonthCount;
            uid = getUID(nextMonthCount, monthOfFillIn.month_index + 1, monthOfFillIn.year);
            days[i].setAttribute('data-uid', uid);
            appendSpriteToCellAndTolltip(uid,days[i]);
            nextMonthCount++;
        }
    }
    changeColor();
}

function getUID(day, month, year) {
    if(month == 12) {
        month = 0;
        year++;
    }
    var uid = day.toString() + month.toString() + year.toString();
    return uid;
}

function appendSpriteToCellAndTolltip(uid,elem) {
    for (let i = 0; i < post_its.length; i++) {
        if(uid == post_its[i].id){
            elem.innerHTML += `<img src='images/note${post_its[i].note_num}.png' alt='A post it note'>`;
            elem.classList.add("tooltip");
            elem.innerHTML += `<span>${post_its[i].note}</span>`;
        }
    }
}

function cleanCells(cells) {
    removeCurrentDay();
    for (let i = 0; i < cells.length; i++) {
        if(cells[i].classList.contains('color')) {
            cells[i].classList.remove('color');
        }
        // if(cells[i].classList.contains('prev-month-last-day')) {
        //     cells[i].remove('prev-month-last-day');
        // }
        if(cells[i].hasAttribute('style')) {
            cells[i].removeAttribute('style');
        }
    }
}

function removeCurrentDay() {
    if (document.getElementById('current-day')) {
        document.getElementById('current-day').removeAttribute('id');
    }
}

function calenderIsCurrentMonth() {
    if (data.current_date.year == data.calender.year && data.current_date.month == data.calender.month) {
        return true;
    } else {
        return false;
    }
}

function nextMonth() {
    if(data.calender.month != 11 || data.calender.year == 2019) {
        data.calender.month++;
    }
    if(data.calender.month >= 12) {
        data.calender.month = 0;
        data.calender.year++;
    }
    fillInCalender();
}

function prevMonth() {
    if(data.calender.month != 11 || data.calender.year == 2020) {
        data.calender.month--;
    }
    if(data.calender.month <= -1) {
        data.calender.month = 11;
        data.calender.year--;
    }
    fillInCalender();
}

function addEventToArray(td_array) {
    for (let i = 0; i < td_array.length; i++) {
        let td = td_array[i];
        td.addEventListener('click', function() {
            dayClicked(td);
        });
    }
}

document.onkeydown = function(e) {
    switch(e.keyCode) {
        case 37:
            prevMonth();
            break;
        case 39:
            nextMonth();
            break;
    }
}
