function togglesidebar()
{
    document.getElementById("sidebar").classList.toggle("active");
    document.getElementById("mainarea").classList.toggle("actives");
}